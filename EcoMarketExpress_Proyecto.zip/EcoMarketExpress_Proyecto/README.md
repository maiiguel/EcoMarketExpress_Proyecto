# EcoMarket Express S.A.S. - Prototipo académico

Prototipo web estático desarrollado con HTML, CSS y JavaScript para realizar pruebas funcionales y de usabilidad.

## Ejecución
1. Descargue `index.html`.
2. Ábralo con Google Chrome, Firefox, Safari o Edge.
3. Use el buscador del catálogo y los controles de cantidad para probar la compra.

## Casos de prueba
- CP-FUN-01: agregar dos unidades de Jabón ecológico; el subtotal debe ser $24.000 COP.
- CP-FUN-02: intentar agregar cantidad cero; debe aparecer un mensaje de validación.
- CP-USU-01: buscar “Detergente ecológico”; debe mostrarse un único resultado.
- CP-USU-02: buscar “Botella reutilizable”, agregar una unidad y verificar el carrito.

## Evidencias
La carpeta `evidencias/` contiene capturas obtenidas durante la ejecución automatizada de los cuatro escenarios en Chromium.

## Alcance y limitaciones
Es un prototipo académico de frontend. No implementa autenticación, pagos, inventario persistente, backend ni conexión a una base de datos. Los resultados corresponden a las pruebas ejecutadas sobre este prototipo, no a un sistema productivo.
